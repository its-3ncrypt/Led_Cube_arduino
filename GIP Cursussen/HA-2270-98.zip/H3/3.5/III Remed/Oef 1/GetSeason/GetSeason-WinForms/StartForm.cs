﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GetSeason_Business;

namespace GetSeason_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        //instantie van de (controller voor de) GetSeason_Business-code
        Controller _controller = new Controller();

        private void dtpDatum_ValueChanged(object sender, EventArgs e)
        {
            string path = @"C:\illustrations\";
            string seizoen = "";

            seizoen = _controller.getSeason(dtpDatum.Value.Date).ToLower();
            path += seizoen + ".gif";

            Image image = Image.FromFile(path);
            pboAfbeelding.Image = image;

            dtpDatum.Visible = false;
            lblSeizoen.Visible = true;
            lblSeizoen.Text = "Het seizoen is " + seizoen;
        }
    }
}
