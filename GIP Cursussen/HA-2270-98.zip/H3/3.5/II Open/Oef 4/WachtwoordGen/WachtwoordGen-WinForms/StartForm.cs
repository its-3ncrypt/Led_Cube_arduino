﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WachtwoordGen_Business;

namespace WachtwoordGen_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        //instantie van business controller uit WachtwoordGen_Business-library
        Controller _controller = new Controller();

        private void btnStart_Click(object sender, EventArgs e)
        {
            lblToon.Text = _controller.getWachtwoord(Convert.ToInt16(txtAantal.Text));
            txtAantal.Visible = false;
            btnStart.Text = "A G A I N !";
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            string copy = "";
            if (lblToon.Text == "Geef aantal tekens op:") copy = "geen ww gegenereerd";
            else copy = lblToon.Text;

            Clipboard.SetText(copy);
        }
    }
}
