﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiceGame_Business;

namespace DiceGame_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Program call = new Program();
            call.mainCode();
        }

        //controller-instantie is globaal en static, dus uniek exemplaar in geheugen voor verschillende "creaties"
        static Controller _controller = new Controller();

        private void mainCode()
        {
            string letter = "", keuze = "", melding = "";

            //init
            Console.Clear(); //niet vergeten!
            Console.WriteLine("Welkom bij 'DiceGame'!");
            Console.WriteLine();

            //eerste worp + uitvoer ervan
            Console.WriteLine("Eerste worp: " + _controller.getWorp1().ToString());
            Console.WriteLine();

            //UI vraagt keuze + bewaart deze door aan business
            Console.WriteLine("Hoger (H) of lager (L)?");
            Console.WriteLine();
            letter = Console.ReadLine();
            //keuze opslaan (moet wel 'H' of 'L' zijn)
            switch (letter)
            {
                case "H":
                    {
                        _controller.setChoice(true);
                        keuze = "HOGER";
                        break;
                    }
                case "L":
                    {
                        _controller.setChoice(false);
                        keuze = "LAGER";
                        break;
                    }
            }
            Console.WriteLine();
            Console.WriteLine("U koos: " + keuze);
            Console.WriteLine();

            //tweede worp + uitvoer
            Console.WriteLine("Tweede worp: " + _controller.getWorp2().ToString());
            Console.WriteLine();

            //uitvoer in console
            if (_controller.getResult()) melding = "gewonnen!";
            else melding = "verloren!";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("U hebt " + melding);
            Console.WriteLine();

            //herstarten of niet
            Console.ResetColor();
            Console.WriteLine("Druk op enter om te herbeginnen, geef 'END' in om te stoppen.");
            Console.WriteLine(); 
            string restart = Console.ReadLine();
            if (restart == "END") Environment.Exit(0);
            else
            {
                Program call = new Program();
                call.mainCode();
            };
        }
    }
}
