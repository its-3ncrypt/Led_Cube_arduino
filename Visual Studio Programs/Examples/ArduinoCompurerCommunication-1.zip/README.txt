If you just want to test the executable file, you need to install the .NET framework files.

https://www.microsoft.com/net/download/framework

If you install the Visual Studio 2017, the .NET framework files are installed automatically.

