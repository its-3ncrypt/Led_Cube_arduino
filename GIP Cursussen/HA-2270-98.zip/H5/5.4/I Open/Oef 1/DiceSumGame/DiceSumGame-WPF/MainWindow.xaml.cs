﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//toegevoegde using-statements
using DiceSumGame_Business;
using System.Windows.Media.Animation;

namespace DiceSumGame_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //instantie van de (controller voor de) business code in de DiceSumGame_Business-library
        Controller _controller = new Controller();

        /* 
         Bron voor animatiecode:
         http://stackoverflow.com/questions/14158500/wpf-animate-background-color
        */

        private void btnSpeel_Click(object sender, RoutedEventArgs e)
        {
            int gok = Convert.ToInt16(txtGok.Text);
            _controller.setGuess(gok);
            
            ColorAnimation animation = new ColorAnimation();
            animation.From = Colors.Black;
            animation.To = Colors.Red;
            animation.Duration = new Duration(TimeSpan.FromSeconds(2));
            this.lblResultaat.Foreground = new SolidColorBrush(Colors.Black);
            this.lblResultaat.Foreground.BeginAnimation(SolidColorBrush.ColorProperty, animation);

            lblResultaat.Content = "U gokte op " + gok.ToString() + " ogen als som." + Environment.NewLine + Environment.NewLine;
            lblResultaat.Content += "De gegooide som van de ogen is: " + _controller.getRoll().ToString() + Environment.NewLine + Environment.NewLine + Environment.NewLine; 
            string melding = "verloren";
            if (_controller.getResult()) melding = "gewonnen";
            lblResultaat.Content += "U hebt " + melding + "!";

            animation.AutoReverse = true; //herstellen na animatie
        }
    }
}
