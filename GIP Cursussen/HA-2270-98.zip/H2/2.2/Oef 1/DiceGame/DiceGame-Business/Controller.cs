﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiceGame_Business
{
    public class Controller
    {
        //controller heeft meer "nut" indien uitwerking volledig volgens OOP...

        //instantie van business code
        private Business _business = new Business();

        /// <summary>
        /// Eerste worp doen
        /// </summary>
        /// <returns>Geeft aantal ogen (van eerste worp)</returns>
        public int getWorp1()
        {
            return _business.getRoll1();
        }

        /// <summary>
        /// Tweede worp doen
        /// </summary>
        /// <returns>Geeft aantal ogen (van tweede worp)</returns>
        public int getWorp2()
        {
            return _business.getRoll2();
        }

        /// <summary>
        /// Instellen keuze gebruiker
        /// </summary>
        /// <param name="choice">true = hoger, false = lager</param>
        public void setChoice(bool choice)
        {
            _business.setChoice(choice);
        }

        /// <summary>
        /// Winst/verlies van gebruiker
        /// </summary>
        /// <returns>true= gewonnen, false = verloren</returns>
        public bool getResult()
        {
            return _business.getResult();
        }
    }
}
