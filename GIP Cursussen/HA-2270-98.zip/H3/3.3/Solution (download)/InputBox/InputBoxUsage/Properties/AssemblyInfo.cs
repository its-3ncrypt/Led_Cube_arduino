﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Obecné informace o sestavení jsou řízeny prostřednictvím následující 
// sadu atributů. Změnou hodnot těchto atributů se upraví informace
// přidružené k sestavení.
[assembly: AssemblyTitle("InputBoxUsage")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("InputBoxUsage")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Nastavení atributu ComVisible na hodnotu False udělá typy v tomto sestavení neviditelné 
// komponent modelu COM.  Pokud potřebujete přistoupit k typu v tomto sestavení z 
// modelu COM, nastavte atribut ComVisible daného typu na hodnotu True.
[assembly: ComVisible(false)]

// Následující GUID je použito pro ID knihovny typů, pokud je tento projekt vystaven COM
[assembly: Guid("cb82c2a1-9f75-49ce-ae8b-4549964bf487")]

// Informace o verzi sestavení se skládá z následujících čtyř hodnot:
//
//      Hlavní verze
//      Dílčí verze 
//      Číslo sestavení
//      Revize
//
// Můžete zadat všechny hodnoty nebo nastavit výchozí očíslování sestavení a revize 
// použitím znaku '*' jak je ukázáno dále:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
