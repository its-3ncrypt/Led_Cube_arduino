﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BtwApp_Business;

namespace BtwApp_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private Controller _controller = new Controller();


        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            _controller.setRate(6);
            showBtw();
            resetInterface();
        }

        private void btn21_Click(object sender, RoutedEventArgs e)
        {
            _controller.setRate(21);
            showBtw();
            resetInterface();
        }

        //hulpprocedures om dubbele code te vermijden
        private void showBtw()
        {
            _controller.setAmount(Convert.ToDouble(txtInvoer.Text));
            string message = "BTW-bedrag: " + _controller.getBtw().ToString();
            message += Environment.NewLine + "Totaalbedrag incl: " + _controller.getTotal().ToString();
            MessageBox.Show(message, "BTW result");
        }

        private void resetInterface()
        {
            txtInvoer.Text = "Bedrag excl. BTW";
        }
    }
}
