﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OnbeperkteSom_Business;

namespace OnbeperkteSom_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        Controller _controller = new Controller();

        private void btnAdd_Click(object sender, EventArgs e)
        {
            _controller.addNumber(txtGetal.Text); 
            /* functionaliteit om "STOP" in te geven is hier niet meer van toepassing!
            => hoort eigenlijk niet bij business layer, maar thuis in presentation code... */
            
            MessageBox.Show(_controller.getSum().ToString(), "SOM");
        }
    }
}
