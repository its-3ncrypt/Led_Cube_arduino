﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PigGame_Business;

namespace PigGame_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Program call = new Program();
            call.mainCode();
        }

        //controller-instantie is globaal en static, dus uniek exemplaar in geheugen voor verschillende "creaties"
        static Controller _controller = new Controller();

        private void mainCode()
        {
            bool _verder = true;

            Console.Title = "PIGGAME";
            Console.Clear(); //niet vergeten!
            Console.WriteLine("Welkom bij PigGame. Probeer 100 punten te halen, zonder een '1' te gooien...");
            Console.WriteLine();

            while (_controller.nextRollAllowed())
            {
                Console.WriteLine("Je worp is gelijk aan {0}", _controller.getLastRoll().ToString());
                Console.WriteLine("Je totaal is gelijk aan {0}", _controller.getTotal().ToString());
                Console.WriteLine();
                Console.Write("Wil je verder spelen (J/N)? ");
                string invoer = Console.ReadLine();
                switch (invoer)
                {
                    case "J":
                        _verder = true;
                        break;
                    case "N":
                        _verder = false;
                        break;
                    default:
                        Console.WriteLine();
                        Console.Write("Wil je verder spelen (J/N)? ");
                        break;
                }
                _controller.setChoice(_verder);
                Console.WriteLine();
            }

            string winst = "";
            if (_controller.getResult()) winst = "gewonnen";
            else winst = "verloren";
            Console.WriteLine();
            Console.WriteLine("Spel beëindigd. U hebt {0}.", winst);
            Console.WriteLine("Uw eindscore is {0}", _controller.getTotal().ToString());
            Console.WriteLine();

            //herstarten of niet
            Console.WriteLine("Druk op enter om te herbeginnen, geef 'END' in om te stoppen.");
            Console.WriteLine();
            string restart = Console.ReadLine();
            if (restart == "END") Environment.Exit(0);
            else
            {
                Program call = new Program();
                call.mainCode();
            };
        }
    }
}
