﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//toegevoegde using-statements
using System.Windows.Media.Animation;
using IBAN_Business;

namespace IBANnr_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Controller _controller = new Controller();

        private void btnValidate_Click(object sender, RoutedEventArgs e)
        {
            _controller.setInput(txtIban.Text);
            
            Color kleur = new Color();
            if (_controller.validateIban()) kleur = Colors.Green;
            else kleur = Colors.Red;

            ColorAnimation anim = new ColorAnimation(kleur, new Duration(TimeSpan.FromSeconds(3)));
            this.grid.Background.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
    }
}
