﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PigGame_Business; //reference toegevoegd

namespace PigGame_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        //instantie van (controller-klasse voor) PigGame_Business
        Controller _controller = new Controller();

        private void btnWerp_Click(object sender, EventArgs e)
        {
            _controller.setChoice(true);
            MagWerpen();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _controller.setChoice(false);
            EindeSpel();
        }

        private void MagWerpen()
        {
            if (_controller.nextRollAllowed()) //false indien worp = 1
            {
                ToonDice(_controller.getLastRoll());
                lblTotaal.Text = _controller.getTotal().ToString();
            }
            else
            {
                lblTotaal.Text = _controller.getTotal().ToString();
                EindeSpel();
            }
        }

        private void ToonDice(int aantalOgen)
        {
            //juiste (absolute) pad toevoegen, ofwel afbeeldingen in juiste map plaatsen!
            string path = @"C:\illustrations\dice-" + aantalOgen.ToString() + ".png";
            
            Image image = Image.FromFile(path);
            picDice.Image = image;
        }

        private void EindeSpel()
        {
            ToonDice(_controller.getLastRoll()); //anders wordt dice-1.png nooit getoond
            string melding = "verloren";
            if (_controller.getResult()) melding = "gewonnen";
            lblUitleg.Text = "U hebt " + melding + Environment.NewLine;
            //mogelijke uitbreiding: aantal spelletjes tonen (andere versie controller)
            btnWerp.Visible = false;
        }
    }
}
