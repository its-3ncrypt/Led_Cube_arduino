﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dice;

namespace DiceSumGame_Business
{
    //niet meer public; controller wel
    class DiceSumGame
    {
        private Dice.Dice _dobbel = new Dice.Dice();
        private int _som, _gok;

        //met deze implementatie: gebruiker komt nooit beide worpen apart te weten
        public int DiceSumGameRoll()
        {
            int som = 0;
            _dobbel.Roll(); som += _dobbel.Pips;
            _dobbel.Roll(); som += _dobbel.Pips;
            _som = som;
            return som;
        }

        public void DiceSumGameGuess(int guess)
        {
            _gok = guess;
        }

        public bool DiceSumGameResult()
        {
            //absolute waarde want de gok mag 1 meer of minder zijn dan de som
            return (Math.Abs(_som - _gok) < 2);
        }
    }
}
