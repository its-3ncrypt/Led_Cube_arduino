﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Binding_VS_CodeBehind
{
    /// <summary>
    /// Interaction logic for Versie2.xaml
    /// </summary>
    public partial class Versie2 : Window
    {
        public Versie2()
        {
            InitializeComponent();
        }

        private void txtNaam_TextChanged(object sender, TextChangedEventArgs e)
        {
            txtNaamUit.Text = txtNaam.Text;
        }
    }
}
