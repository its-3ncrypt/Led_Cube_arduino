﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBAN_Business;

namespace IBAN_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }
        
        //instantie van (de controller voor) de business code
        Controller _controller = new Controller();

        private void btnCheck_Click(object sender, EventArgs e)
        {
            _controller.setInput(txtInvoer.Text);
            if (_controller.validateIban()) MessageBox.Show("Geldig IBAN-nr: " + _controller.getIban(), "IBAN");
            else MessageBox.Show("Ongeldig IBAN-nr: " + _controller.getIban(), "IBAN");
        }
    }
}
