﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DiceSumGame_Business;

namespace DiceSumGame_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        //instantie van business controller uit DiceSumGame_Business-library
        Controller _controller = new Controller();

        private void cboGok_SelectedIndexChanged(object sender, EventArgs e)
        {
            _controller.setGuess(Convert.ToInt16(cboGok.SelectedItem));
            lblMelding.Text = "De worp was gelijk aan " + _controller.getRoll().ToString();
            if (_controller.getResult()) this.BackColor = Color.LightGreen;
            else this.BackColor = Color.Coral;
        }
    }
}
