﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DiceGame_Business;

namespace DiceGame_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //instantie van de (controller voor de) business code in de DiceGame_Business-library
        Controller _controller = new Controller();

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            btnStart.Visibility = Visibility.Hidden;
            lblUitvoer.Content += Environment.NewLine + Environment.NewLine + "De eerste worp telt " + _controller.getWorp1().ToString() + " ogen.";

            btnLager.Visibility = Visibility.Visible;
            btnHoger.Visibility = Visibility.Visible;
        }


        //hulpfunctie tegen dubbele code na het maken van keuze
        private void keuzeGemaakt()
        {
            string melding = "verloren";

            lblUitvoer.Content += Environment.NewLine + Environment.NewLine + "De tweede worp telt " + _controller.getWorp2().ToString() + " ogen.";

            if (_controller.getResult()) melding = "gewonnen";
            
            //slot-uitvoer in UI
            lblUitvoer.Content += Environment.NewLine + Environment.NewLine + "U hebt " + melding + "!";
        }

        private void btnLager_Click(object sender, RoutedEventArgs e)
        {
            _controller.setChoice(false);
            btnHoger.Visibility = Visibility.Hidden;
            keuzeGemaakt();
        }

        private void btnHoger_Click(object sender, RoutedEventArgs e)
        {
            _controller.setChoice(true);
            btnLager.Visibility = Visibility.Hidden;
            keuzeGemaakt();
        }
    }
}
