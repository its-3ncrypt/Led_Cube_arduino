﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBAN_Business
{
    public class Controller
    {
        Business _business = new Business();

        public bool setInput(string invoer)
        {
            if (_business.setIban(invoer)) return true;
            else return false;
        }

        public string getIban()
        {
            if (_business.validateIban()) return _business.Iban;
            else return "foutief formaat";
        }

        public bool validateIban()
        {
            return _business.validateIban();
        }
    }
}
