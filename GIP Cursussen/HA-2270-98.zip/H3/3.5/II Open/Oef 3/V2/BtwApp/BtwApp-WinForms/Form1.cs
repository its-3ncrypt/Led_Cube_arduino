﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BtwApp_Business;

namespace BtwApp_WinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //instantie van business controller uit BtwApp_Business-library
        Controller _controller = new Controller();

        private void btnCalc_Click(object sender, EventArgs e)
        {
            _controller.setAmount(Convert.ToDouble(txtInvoer.Text));
            _controller.setRate(Convert.ToInt16(cboTarief.SelectedItem));
            lblUitvoer.Text = "BTW-bedrag: " + _controller.getBtw().ToString("C2");
            lblUitvoer.Text += Environment.NewLine + "Totaalbedrag: " + _controller.getTotal().ToString("C2");
            btnCalc.Visible = false;
            btnReset.Visible = true;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtInvoer.Clear();
            cboTarief.SelectedIndex = -1;
            txtInvoer.Focus();
            lblUitvoer.Text = "";
            btnCalc.Visible = true;
            btnReset.Visible = false;
        }
    }
}
