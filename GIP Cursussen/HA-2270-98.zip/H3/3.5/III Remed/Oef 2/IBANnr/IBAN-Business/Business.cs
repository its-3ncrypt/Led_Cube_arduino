﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBAN_Business
{
    class Business
    {
        //velden bij eigenschap
        private string _country;
        private long _ibanPart1;
        private int _ibanPart2;
        public string Iban  //beter: aparte IBAN-klasse met een override voor ToString
        {
            get { return _country + addZeros(_ibanPart1, 10) + addZeros(_ibanPart2, 2); } 
            //geen setter; enkel methode setIban kan gebruikt worden
        }

        private string addZeros(long number, int length)
        {
            string temp = number.ToString();
            int count = temp.Length;
            if (count == length) return temp;
            else
            {
                for (int i = count; i < length; i++)
                {
                    temp = "0" + temp;
                }
                return temp;
            }
        }

        public bool setIban(string number)
        {
            if (number.Length != 16) return false;
            else
            {
                if (number.Substring(0, 2) != "BE") return false;
                else
                {
                    _country = number.Substring(0, 4); //BE23
                    _ibanPart1 = Convert.ToInt64(number.Substring(4, 10)); //0000456273
                    _ibanPart2 = Convert.ToInt16(number.Substring(14, 2)); //82
                    return true;
                }
            }
        }

        public bool validateIban() //Iban-eigenschap moet ingesteld zijn
        {
            if ((_ibanPart1 % 97) == _ibanPart2) return true; 
                //rest van eerste gedeeld door 97 moet gelijk zijn aan tweede 
            else return false;
        }
    }
}
