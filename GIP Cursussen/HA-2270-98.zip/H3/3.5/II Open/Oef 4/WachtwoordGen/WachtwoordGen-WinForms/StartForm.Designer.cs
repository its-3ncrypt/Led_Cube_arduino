﻿namespace WachtwoordGen_WinForms
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblToon = new System.Windows.Forms.Label();
            this.txtAantal = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblToon
            // 
            this.lblToon.AutoSize = true;
            this.lblToon.Location = new System.Drawing.Point(13, 13);
            this.lblToon.Name = "lblToon";
            this.lblToon.Size = new System.Drawing.Size(115, 13);
            this.lblToon.TabIndex = 0;
            this.lblToon.Text = "Geef aantal tekens op:";
            // 
            // txtAantal
            // 
            this.txtAantal.Location = new System.Drawing.Point(135, 5);
            this.txtAantal.Name = "txtAantal";
            this.txtAantal.Size = new System.Drawing.Size(67, 20);
            this.txtAantal.TabIndex = 1;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(16, 45);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(186, 23);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "G E N E R A T E";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(16, 72);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(186, 23);
            this.btnCopy.TabIndex = 3;
            this.btnCopy.Text = "COPY TO CLIPBOARD";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(214, 107);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtAantal);
            this.Controls.Add(this.lblToon);
            this.Name = "StartForm";
            this.Text = "WW-Gen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblToon;
        private System.Windows.Forms.TextBox txtAantal;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnCopy;
    }
}

