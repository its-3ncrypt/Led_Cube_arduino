﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DiceGameBusiness;

namespace DiceGame_ASP
{
    public partial class _default : System.Web.UI.Page
    {
        //var voor communicatie met Business Layer
        DGBusiness business = new DGBusiness();

        protected void btnStart_Click(object sender, EventArgs e)
        {
            int worp1; //zou ook intWorp kunnen heten

            btnStart.Visible = false;
            worp1 = business.DiceGameRoll1();
            lblUitvoer.Text = "De eerste worp telt " + worp1.ToString() + " ogen.";
            //hier = ipv += want startmelding is dan weg

            btnLager.Visible = true;
            btnHoger.Visible = true;
        }

        protected void btnLager_Click(object sender, EventArgs e)
        {
            business.DiceGameChoice(false);
            btnHoger.Visible = false;
            keuzeGemaakt();
        }

        protected void btnHoger_Click(object sender, EventArgs e)
        {
            business.DiceGameChoice(true);
            btnLager.Visible = false;
            keuzeGemaakt();
        }

        //hulpfunctie tegen dubbele code na het maken van keuze
        private void keuzeGemaakt()
        {
            int worp2; //zou ook intWorp kunnen heten
            bool winst;
            string melding = "verloren!";

            worp2 = business.DiceGameRoll2();
            lblUitvoer.Text += "<br />" + "<br />" + "De tweede worp telt " + worp2.ToString() + " ogen.";

            winst = business.DiceGameResult();

            //var al geïnitialiseerd als 'verloren', dus geen else nodig
            if (winst)
            {
                melding = "gewonnen!";
            }
            //slot-uitvoer in UI
            lblUitvoer.Text += "<br />" + "<br />" + "U hebt " + melding;
        }
    }
}