﻿namespace DiceSumGame_WinForms
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboGok = new System.Windows.Forms.ComboBox();
            this.lblMelding = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cboGok
            // 
            this.cboGok.FormattingEnabled = true;
            this.cboGok.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboGok.Location = new System.Drawing.Point(244, 10);
            this.cboGok.Name = "cboGok";
            this.cboGok.Size = new System.Drawing.Size(67, 21);
            this.cboGok.TabIndex = 0;
            this.cboGok.SelectedIndexChanged += new System.EventHandler(this.cboGok_SelectedIndexChanged);
            // 
            // lblMelding
            // 
            this.lblMelding.AutoSize = true;
            this.lblMelding.Location = new System.Drawing.Point(13, 13);
            this.lblMelding.Name = "lblMelding";
            this.lblMelding.Size = new System.Drawing.Size(225, 13);
            this.lblMelding.TabIndex = 1;
            this.lblMelding.Text = "Selecteer jouw gok voor de som van de ogen:";
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 42);
            this.Controls.Add(this.lblMelding);
            this.Controls.Add(this.cboGok);
            this.Name = "StartForm";
            this.Text = "DICESUMGAME";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboGok;
        private System.Windows.Forms.Label lblMelding;
    }
}

