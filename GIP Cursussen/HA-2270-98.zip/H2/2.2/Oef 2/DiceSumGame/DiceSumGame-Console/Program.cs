﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiceSumGame_Business;

namespace DiceSumGame_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Program call = new Program();
            call.mainCode();
        }

        //controller-instantie is globaal en static, dus uniek exemplaar in geheugen voor verschillende "creaties"
        static Controller _controller = new Controller();

        private void mainCode()
        {
            string gok = "", melding = "";

            //init
            Console.ForegroundColor = ConsoleColor.White;
            Console.Title = "DICESUMGAME";
            Console.Clear(); //niet vergeten!
            Console.WriteLine("Welkom bij 'DiceSumGame'!");
            Console.WriteLine();

            //UI vraagt keuze en slaat op in business layer
            Console.WriteLine("Wat is uw gok voor de som van beide worpen?");
            Console.WriteLine();
            gok = Console.ReadLine();
            _controller.setGuess(Convert.ToInt16(gok));

            //worpen + uitvoer ervan
            Console.WriteLine();
            Console.WriteLine("Som van de ogen: " + _controller.getRoll().ToString());
            Console.WriteLine();

            //winst-verlies
            if (_controller.getResult()) melding = "gewonnen";
            else melding = "verloren";
            Console.WriteLine("U hebt " + melding + "!");
            Console.WriteLine();

            //herstarten of niet
            Console.WriteLine("Druk op enter om te herbeginnen, geef 'END' in om te stoppen.");
            Console.WriteLine();
            string restart = Console.ReadLine();
            if (restart == "END") Environment.Exit(0);
            else
            {
                Program call = new Program();
                call.mainCode();
            };
        }
    }
}
