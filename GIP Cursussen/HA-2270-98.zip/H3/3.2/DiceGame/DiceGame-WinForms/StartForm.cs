﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DiceGame_Business;

namespace DiceGame_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        //instantie van business controller uit DiceGame_Business-library
        Controller _controller = new Controller();

        private void btnStart_Click(object sender, EventArgs e)
        {
            lblUitvoer.Text += Environment.NewLine + "De eerste worp is gelijk aan " + _controller.getWorp1().ToString();
            lblUitvoer.Text += Environment.NewLine + "Maak uw keuze: hoger of lager";
            btnHoger.Visible = true;
            btnLager.Visible = true;
        }

        private void btnLager_Click(object sender, EventArgs e)
        {
            _controller.setChoice(false);
            btnHoger.Visible = false;
            keuzeGemaakt();
        }

        private void btnHoger_Click(object sender, EventArgs e)
        {
            _controller.setChoice(true);
            btnLager.Visible = false;
            keuzeGemaakt();
        }

        //hulpprocedure om dubbele code te vermijden
        private void keuzeGemaakt()
        {
            lblUitvoer.Text += Environment.NewLine + "De tweede worp is gelijk aan " + _controller.getWorp2().ToString();

            string result = "verloren"; //default
            if (_controller.getResult()) result = "gewonnen";
            lblUitvoer.Text += Environment.NewLine + "U hebt " + result + "!";
            //slechts één keer spelen; cf. latere uitbreidingen
            btnStart.Visible = false;
            btnLager.Visible = false;
            btnHoger.Visible = false;
        }
    }
}
