﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PigGame_Business
{
    public class Controller
    {
        Business _business = new Business();
        
        //globale var voor keuze gebruiker
        private bool _choice = true;
        /// <summary>
        /// Instellen keuze gebruiker.
        /// </summary>
        /// <param name="choice">True= wil opnieuw gooien; false = wil stoppen</param>
        public void setChoice(bool choice)
        {
            _choice = choice; //invoer; keuze gebruiken (opnieuw gooien of niet)
        }

        //Cf. while-structuur in presentation layer
        /// <summary>
        /// Is een volgende worp mogelijk?
        /// </summary>
        /// <returns>True = volgende worp kan; false = spel is gedaan</returns>
        public bool nextRollAllowed()
        {
            return _business.nextRoll(_choice); //keuze gebruiker moet eerst ingesteld zijn
        }

        /// <summary>
        /// Opvragen resultaat voorgaande worp.
        /// </summary>
        /// <returns>Aantal ogen van worp</returns>
        public int getLastRoll()
        {
            return _business.Worp;
        }

        /// <summary>
        /// Opvragen totaalscore.
        /// </summary>
        /// <returns>Waarde totale score</returns>
        public int getTotal()
        {
            return _business.Score;
        }

        /// <summary>
        /// Resultaat van het spel.
        /// </summary>
        /// <returns>True = gewonnen; false = verloren</returns>
        public bool getResult()
        {
            return _business.getResult();
        }
    }
}
