﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Oefening6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /* 
            Zonder binding, dus tekstvakken worden aangepast vanuit deze C#-code
            Hulpprocedure om 3 x dezelfde code om achtergrond aan te passen, te vermijden
        */

        private void slColorR_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            txtR.Text = slColorR.Value.ToString("0");
            Achtergrond();
        }

        private void slColorG_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            txtG.Text = slColorG.Value.ToString("0");
            Achtergrond();
        }

        private void slColorB_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            txtB.Text = slColorB.Value.ToString("0");
            Achtergrond();
        }

        private void Achtergrond()
        {
            Color objColor = Color.FromRgb((byte)slColorR.Value, (byte)slColorG.Value, (byte)slColorB.Value);
            SolidColorBrush objBrush = new SolidColorBrush(objColor);
            this.Background = objBrush;
        }
    }
}
