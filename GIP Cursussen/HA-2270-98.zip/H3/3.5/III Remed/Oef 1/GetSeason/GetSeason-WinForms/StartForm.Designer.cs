﻿namespace GetSeason_WinForms
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpDatum = new System.Windows.Forms.DateTimePicker();
            this.pboAfbeelding = new System.Windows.Forms.PictureBox();
            this.lblSeizoen = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pboAfbeelding)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpDatum
            // 
            this.dtpDatum.Location = new System.Drawing.Point(13, 13);
            this.dtpDatum.Name = "dtpDatum";
            this.dtpDatum.Size = new System.Drawing.Size(200, 20);
            this.dtpDatum.TabIndex = 0;
            this.dtpDatum.ValueChanged += new System.EventHandler(this.dtpDatum_ValueChanged);
            // 
            // pboAfbeelding
            // 
            this.pboAfbeelding.Location = new System.Drawing.Point(13, 64);
            this.pboAfbeelding.Name = "pboAfbeelding";
            this.pboAfbeelding.Size = new System.Drawing.Size(200, 252);
            this.pboAfbeelding.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pboAfbeelding.TabIndex = 1;
            this.pboAfbeelding.TabStop = false;
            // 
            // lblSeizoen
            // 
            this.lblSeizoen.Location = new System.Drawing.Point(13, 13);
            this.lblSeizoen.Name = "lblSeizoen";
            this.lblSeizoen.Size = new System.Drawing.Size(200, 36);
            this.lblSeizoen.TabIndex = 2;
            this.lblSeizoen.Visible = false;
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(227, 328);
            this.Controls.Add(this.lblSeizoen);
            this.Controls.Add(this.pboAfbeelding);
            this.Controls.Add(this.dtpDatum);
            this.Name = "StartForm";
            this.Text = "GET SEASON";
            ((System.ComponentModel.ISupportInitialize)(this.pboAfbeelding)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpDatum;
        private System.Windows.Forms.PictureBox pboAfbeelding;
        private System.Windows.Forms.Label lblSeizoen;
    }
}

