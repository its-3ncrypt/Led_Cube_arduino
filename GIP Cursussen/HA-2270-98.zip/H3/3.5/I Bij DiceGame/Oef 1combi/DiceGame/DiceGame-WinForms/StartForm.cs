﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DiceGame_Business;

namespace DiceGame_WinForms
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        //instantie van business controller uit DiceGame_Business-library
        Controller _controller = new Controller();

        private void btnStart_Click(object sender, EventArgs e)
        {
            lblUitvoer.Text += Environment.NewLine + "De eerste worp is gelijk aan " + _controller.getWorp1().ToString();
            
            if (MessageBox.Show("Kies je voor hoger? (Nee = lager)", "DiceGame MessageBox", MessageBoxButtons.YesNo) == DialogResult.Yes) _controller.setChoice(true);
            else _controller.setChoice(false); //keuze = Nee = lager = false

            lblUitvoer.Text += Environment.NewLine + "De tweede worp is gelijk aan " + _controller.getWorp2().ToString();

            string result = "verloren"; //default
            if (_controller.getResult())
            {
                result = "gewonnen";
                this.BackColor = Color.LightGreen; //achtergrondkleur veranderen
            }
            else this.BackColor = Color.Coral; //achtergrondkleur veranderen
            lblUitvoer.Text += Environment.NewLine + "U hebt " + result + "!";
        }
    }
}
