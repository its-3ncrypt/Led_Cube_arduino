﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiceLibrary; //klasse Dice

namespace DiceGameBusiness
{
    public class DGBusiness
    {
        private Dice dobbel = new Dice();

        //letterlijke code van 03B
        //business layer

        private int worp1, worp2;
        private bool keuze;

        public int DiceGameRoll1()
        {
            dobbel.Roll();
            worp1 = dobbel.Pips;
            return worp1;
        }

        public void DiceGameChoice(bool choice) //setChoice-methode
        {
            keuze = choice;
        }

        public int DiceGameRoll2()
        {
            dobbel.Roll();
            worp2 = dobbel.Pips;
            return worp2;
        }

        public bool DiceGameResult() //getResult-methode
        {
            bool result = false;
            if (keuze) if (worp1 < worp2) result = true;
            else if (worp1 > worp2) result = true;
            return result;
        }
    }
}
