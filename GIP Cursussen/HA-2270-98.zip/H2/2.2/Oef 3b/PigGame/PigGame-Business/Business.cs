﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dice;

namespace PigGame_Business
{
    class Business
    {
        Dice.Dice _dobbel = new Dice.Dice();

        //veld en eign.voor laatste worp
        private int _worp = 0;
        public int Worp
        {
            get { return _worp; }
        }
        
        //veld en eign. voor score tijdens spelbeurt
        private int _score = 0;
        public int Score
        {
            get { return _score; } //read-only
        }

        //veld en eign. voor aantal spelletjes
        private int _aantal = 0;
        public int Aantal
        {
            get { return _aantal; }
        }

        //methoden voor spel
        public bool nextRoll(bool choice) //choice: keuze gebruiker (true = wil verder spelen)
        {
            _dobbel.Roll();
            _worp = _dobbel.Pips;
            if (_worp == 1)
            {
                _score += _worp; //'1' nog wel bijtellen
                _aantal += 1; //dit spelletje is voorbij
                return false;
            }
            else
            {
                if (choice)
                {
                    bool winst = true;
                    _score += _worp;
                    if (_score > 100)
                    {
                        winst = false;
                        _aantal += 1; //dit spelletje is voorbij
                    }
                    else winst = true; //niet echt noodzakelijk
                    return winst; 
                }
                else
                {
                    _aantal += 1; //dit spelletje is voorbij
                    return false;
                }
            }
        }

        public bool getResult()
        {
            if (_worp == 1) return false;
            else //moet verder uitgewerkt worden bij implementatie meerdere spelers
            {
                if (_score > 100) return true;
                else return false;
            }
        }
    }
}
