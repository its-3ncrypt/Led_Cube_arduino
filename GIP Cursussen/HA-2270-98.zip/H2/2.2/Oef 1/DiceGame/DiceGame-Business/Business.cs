﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dice;

namespace DiceGame_Business
{
    class Business
    {
        private int _worp1, _worp2;
        private bool _keuze; 
        private Dice.Dice _dobbel = new Dice.Dice();
        
        //Eerste aanroep in UI
        public int getRoll1()
        {
            _dobbel.Roll();
            _worp1 = _dobbel.Pips;
            return _worp1;
        }
        
        //keuze uit UI wegschrijven in globale var
        /// <summary>
        /// instellen keuze gebruiker
        /// </summary>
        /// <param name="choice">true = hoger, false = lager</param>
        public void setChoice(bool choice)
        {
            _keuze = choice; 
        }
        
        public int getRoll2()
        {
            _dobbel.Roll();
            _worp2 = _dobbel.Pips;
            return _worp2;
        }
        
        public bool getResult()
        {
            bool winst = false;
            if (_keuze)
            {
                if (_worp1 < _worp2) winst = true;
            }
            else //keuze gebruiker = lager
            {
                if (_worp1 > _worp2) winst = true;
            }
            return winst;
        }
    }
}
