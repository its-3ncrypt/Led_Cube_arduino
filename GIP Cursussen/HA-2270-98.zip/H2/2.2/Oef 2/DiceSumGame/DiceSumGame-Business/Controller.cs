﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiceSumGame_Business
{
    public class Controller
    {
        private DiceSumGame _business = new DiceSumGame();

        /// <summary>
        /// Instellen van de gok van de gebruiker.
        /// </summary>
        /// <param name="sum">Integer; gok voor som v.d. ogen</param>
        public void setGuess(int sum)
        {
            _business.DiceSumGameGuess(sum); //invoer; gok
        }

        /// <summary>
        /// Opvragen van het resultaat van de beide worpen.
        /// </summary>
        /// <returns>Som v.d. ogen</returns>
        public int getRoll()
        {
            return _business.DiceSumGameRoll();
        }

        /// <summary>
        /// Opvragen van het resultaat van het spel.
        /// </summary>
        /// <returns>True = gewonnen; false = verloren</returns>
        public bool getResult()
        {
            return _business.DiceSumGameResult();
        }
    }
}
